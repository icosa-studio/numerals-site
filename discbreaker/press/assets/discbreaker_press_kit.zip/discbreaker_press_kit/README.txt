Discbreaker press kit
=====================

A sports roguelite where sponsors bend the rules.

Create your club. Draft a squad from packs. Stack sponsors and gear until no two runs play alike.
Ghost passes slip through defenders, tackles pop the disc toward their net. Win a 256-team knockout cup with the club you built, or host your own online cup for up to 256 players.

CREATE YOUR CLUB
Every run is played with a club of your own: its name, two colours, a crest built from a logo and lettering, and its kits. The crest goes on the pitch, the scoreboard and every card.
- Name, colours, crest, lettering
- Home and inverted kits
- Change it any time, for free

BUILD A SQUAD
Every run starts with tickets and an empty dressing room. Buy packs, open them, sign players and kit them out before the first whistle.
- Ten pack shapes: the better the grade, the smaller the pack
- A ticket allowance, so no two squads match
- Formations set how your five line up

BEND THE RULES
Ghost passes slip through defenders. Tackles pop the disc toward their net. Stack sponsors on the crest and gear on your players until the match plays your way.
- Up to six sponsors, each a rule for the whole side
- Gear on every player
- A shop after every win: reroll or buy packs

NO TWO RUNS ALIKE
A new 256-team bracket every run, and one loss ends it. Fame opens dynasty perks, and the veterans you keep bring their traits into the next run.
- Eight knockout rounds to the final
- Veterans carry over; traits come only from them
- Dynasty perks: a bigger purse, more veterans

UP TO 256 PLAYERS
Friend cups: host an online tournament for your friends or your whole community. Everyone builds a squad on the spot, by draft or from sealed packs, then it's a knockout to the final. Up to 256 players in one cup.

Features
- Create your own club: name, colours, crest, kits
- Online friend cups for up to 256 players
- 256-team knockout cup, a new bracket every run
- Sponsors that change the rules of the match
- Draft from packs, gear on every player
- Veterans, traits and dynasty perks between runs
- 5v5 arcade disc sport with full contact
- Full controller support, 15 languages
A gamepad is recommended (Xbox and PlayStation); keyboard and mouse are fully supported.

Fact sheet
- Genre: Sports roguelite
- Players: Solo campaign, online cups up to 256
- Languages: 15
- Release: Q2 2027
- Demo: Steam Next Fest, Feb 2027
- Platforms: Windows, Linux (Steam)
- Developer: ZER0
- Publisher: Numerals
- Based in: Montreal, Canada

Links
- Trailer: https://www.youtube.com/watch?v=VO5xqFK4ogM
- Steam: https://store.steampowered.com/app/5175180/
- Contact: zero@numerals.io

In this folder
- discbreaker_press_kit.pdf: three-page press sheet: the pitch and fact sheet, your club, the run, friend cups
- logo/: the wordmark (transparent PNG) and the square icon
- key_art/: store capsules and hero art
- screenshots/: 5 in-game screenshots, 1920x1080

The art is pixel art: scale it by whole numbers with nearest-neighbour filtering to keep it sharp.

© 2026 Numerals. All rights reserved. Images may be used for coverage of the game.
